#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/hash.h>
#include <linux/gcd.h>

#include <asm/param.h>
#include <linux/jiffies.h>

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("Simple Module");
MODULE_AUTHOR("SGG");

long int old_jiffies;

/* This function is called when the module is loaded. */ 
int __init simple_init(void)
{
	printk(KERN_INFO "Loading Kernel Module∖n");
	printk(KERN_INFO "%llu\n", GOLDEN_RATIO_PRIME);
	printk(KERN_INFO "HZ[%d], jiffies[%ld]\n", HZ, jiffies);
	old_jiffies = jiffies;
	pr_info("greetings\n");
	return 0;
}
/* This function is called when the module is removed. */ 
void __exit simple_exit(void)
{
	printk(KERN_INFO "Removing Kernel Module∖n"); 
	printk(KERN_INFO "%ld\n", gcd(3300, 24));
	printk(KERN_INFO "HZ[%d], jiffies[%ld], eplased second[%ld]\n", HZ, jiffies, (jiffies - old_jiffies)/HZ);
	pr_info("goodbye\n");
}
/* Macros for registering module entry and exit points. */
module_init(simple_init);
module_exit(simple_exit);

